/*
const myfunc = require("./2. Packages,Modules,export package")

console.log(myfunc())
*/

// Import ES6 Modules
/*
import defaultFunc, {x,y} from "./2. Packages,Modules,export package.js"

console.log(x())

console.log(defaultFunc())

*/

