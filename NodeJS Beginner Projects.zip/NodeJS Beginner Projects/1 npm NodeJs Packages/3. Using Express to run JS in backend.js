// to install Express
/*
npm install express

*/

const express = require('express')
const app = express()
const port = 3000

//localhost:300/
app.get('/', (req, res) => {
    //console.log(req)
    //console.log(res)
  res.send('Hello World!')
})

//localhost:300/about
app.get('/about', (req, res) => {
    //console.log(req)
    //console.log(res)
   // res.send('Hello About!')
    // to send file to next page
    console.log(__dirname)
    try{
      const path = require('path');
      
      res.sendFile(path.join(__dirname,"\MyPDF.pdf"))
    }catch(ex){
      console.log(ex)
    }

  })

app.listen(port, () => {
  console.log(`Example app listening on port  http://localhost:${port}`)
})