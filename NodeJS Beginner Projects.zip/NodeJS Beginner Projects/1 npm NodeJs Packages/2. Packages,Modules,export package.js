// to use the function in another function
/*
this is not ES6 Module
const a = () =>{
    return "hello world"
}

const b = () =>{
    return "hello world"
}

module.exports = {a,b}; // to export a function
*/

// ES6 Modules Export & Import
// to make project as ES6 Module in package.json add
// "type": "module",
/*
export const x = () =>{
    return "hello world"
}

export const y = () =>{
    return "hello world"
}

// to pass default function as it is without creating an object of it
export default  () =>{
    return "hello world"
}
*/





