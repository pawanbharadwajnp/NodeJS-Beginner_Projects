const fs = require('fs');
const path = require('path')
const replaceThis = "Pawan"
const replaceWith ="PB"

try {
  const data = fs.readdir("MyFolder",(err,data)=>
  {
    for (let index = 0; index < data.length; index++) {
        const item = data[index];
        let NewFile = path.join(__dirname + item.replaceAll(replaceThis,replaceWith) )

        fs.rename(path.join(__dirname +item),NewFile,()=>
        {
            console.log("Rename Sucess")
        })       
    }
  })
} catch (err) {
  console.error(err);
}
